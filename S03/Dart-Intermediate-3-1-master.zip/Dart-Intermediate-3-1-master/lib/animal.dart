class Animal {
  String name = 'UNKNOWN';

  Animal(String name) {
    //String name = 'hello';
    name = name;


    print(this.name);
  }
}