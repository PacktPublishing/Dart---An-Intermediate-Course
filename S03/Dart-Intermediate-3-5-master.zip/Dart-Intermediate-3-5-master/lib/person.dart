class Person {
  int _age;

  Person(int age) {
    _age = age;
  }

  int get age => _age;
}