import 'employee.dart';

class Cashier extends Employee {
  @override
  void sayHello() => print('Hello from the Cashier class');
}