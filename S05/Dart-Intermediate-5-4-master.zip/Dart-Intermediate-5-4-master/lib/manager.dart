import 'employee.dart';

class Manager extends Employee {
  @override
  void sayHello() => print('Hello from the Manager class');
}