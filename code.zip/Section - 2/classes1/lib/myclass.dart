
class MyClass {
  void sayHello(String name) => print('Hello ${name}');
}
