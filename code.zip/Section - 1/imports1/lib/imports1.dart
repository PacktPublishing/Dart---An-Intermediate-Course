int calculate() {
  return 6 * 7;
}

void sayHello() {
  print('Hello World');
}