class Employee {
  void sayHello() => print('Hello from the Employee class');
}