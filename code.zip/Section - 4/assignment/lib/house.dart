
abstract class House {
  int rooms;
  void ringDoorBell();
}