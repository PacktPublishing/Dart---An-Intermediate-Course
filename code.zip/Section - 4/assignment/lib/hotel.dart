class Hotel {
  int guests = 0;
}