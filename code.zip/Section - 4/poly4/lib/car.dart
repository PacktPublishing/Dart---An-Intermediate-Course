abstract class Car {

  bool hasWheels;
  bool hasHorn;

  //void honk();

  void honk() => print('honk called in car');

}