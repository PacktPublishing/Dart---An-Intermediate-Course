class Ghost {
  bool walksThoughWalls = true;

  void test() {
    print('Test called in Ghost');
  }
}