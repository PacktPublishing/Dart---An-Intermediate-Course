class Employee {

  String name = '';

  void test() => print('test');
}