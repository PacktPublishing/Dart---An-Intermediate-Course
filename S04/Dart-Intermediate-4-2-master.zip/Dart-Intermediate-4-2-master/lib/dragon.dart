class Dragon {
  bool breathsFire = true;

  void fly() => print('flying');


  void test() {
    print('Test called in Dragon');
  }
}