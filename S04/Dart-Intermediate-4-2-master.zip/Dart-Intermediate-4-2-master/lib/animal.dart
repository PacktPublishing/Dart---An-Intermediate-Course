class Animal {

  bool isAlive = true;

  void breath() => print('breathing');

}